//
//  ParliamentSwiftApp.swift
//  ParliamentSwift
//
//  Created by Trang Vu on 4.11.2024.
//

import SwiftUI

@main
struct ParliamentSwiftApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
