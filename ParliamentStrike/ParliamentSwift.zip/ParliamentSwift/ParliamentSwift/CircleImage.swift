// CircleImage.swift
// ParliamentSwift
//
// Created by Trang Vu on 4.11.2024.
//

import SwiftUI

struct CircleImage: View {
    let imageName: String?

    var body: some View {
        if let imageName = imageName {
            Image(imageName)
                .resizable()
                .clipShape(Circle())
                .overlay {
                    Circle().stroke(.white, lineWidth: 4)
                }
                .shadow(radius: 7)
        } else {
            ProgressView() // Placeholder if imageName is nil
        }
    }
}

#Preview {
    CircleImage(imageName: "defaultImage") // Replace with a sample image from Assets for preview
}
