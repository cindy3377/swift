import SwiftUI
import Foundation

// Member struct with data
struct Member: Codable, Identifiable {
    var id: Int { personNumber }
    let personNumber: Int
    let seatNumber: Int
    let last: String
    let first: String
    let party: String
    let minister: Bool
    let picture: String
    let twitter: String
    let bornYear: Int
    let constituency: String
}

// View for displaying each member's details
struct MemberDetailView: View {
    let member: Member
    
    @EnvironmentObject var favoriteManager: FavoriteManager

    var body: some View {
        VStack {
            // Display party-specific banner image from assets
            Image(member.partyImageName())
                .resizable()
                .scaledToFill()
                .frame(height: 300)
                .clipped()

            CircleImage(imageName: member.partyImageName())
                .offset(y: -130)
                .padding(.bottom, -130)

            VStack(alignment: .leading) {
                Text("\(member.first) \(member.last)")
                    .font(.title)

                HStack {
                    Text(member.constituency)
                        .font(.subheadline)
                    Spacer()
                    Text(member.party.uppercased())
                        .foregroundColor(Color.color(for: member.party))
                        .font(.subheadline)
                }
                .foregroundStyle(.secondary)

                Divider()

                Text("About \(member.first)")
                    .font(.title2)

                VStack(alignment: .leading, spacing: 8) {
                    Text("Seat Number: \(member.seatNumber)")
                    Text("Minister: \(member.minister ? "Yes" : "No")")
                    Text("Born Year: \(member.bornYear)")
                    if !member.twitter.isEmpty {
                        Link("Twitter: \(member.twitter)", destination: URL(string: member.twitter)!)
                            .foregroundColor(.blue)
                    }
                }
                .font(.body)
                .padding(.top, 8)

                // Favorite Button
                Button(action: toggleFavorite) {
                    Label(favoriteManager.isFavorite(member: member) ? "Remove from Favorites" : "Add to Favorites",
                          systemImage: favoriteManager.isFavorite(member: member) ? "heart.fill" : "heart")
                        .foregroundColor(favoriteManager.isFavorite(member: member) ? .red : .primary)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 10)
                        .stroke(favoriteManager.isFavorite(member: member) ? Color.red : Color.gray, lineWidth: 1))
                }
                .padding(.top, 20)
            }
            .padding()

            Spacer()
        }
    }

    // Toggle the favorite status of the current member
    private func toggleFavorite() {
        favoriteManager.toggleFavorite(for: member)
    }
}

// ObservableObject to manage favorites and handle AppStorage
class FavoriteManager: ObservableObject {
    @AppStorage("favoriteMemberIDs") private var favoriteMemberIDsString: String = "[]"
    
    // Use a computed property to decode and encode favoriteMemberIDs
    private var favoriteMemberIDs: [Int] {
        get {
            guard let data = favoriteMemberIDsString.data(using: .utf8) else { return [] }
            return (try? JSONDecoder().decode([Int].self, from: data)) ?? []
        }
        set {
            if let data = try? JSONEncoder().encode(newValue),
               let jsonString = String(data: data, encoding: .utf8) {
                favoriteMemberIDsString = jsonString
            }
        }
    }

    // Check if a member is in the favorite list
    func isFavorite(member: Member) -> Bool {
        return favoriteMemberIDs.contains(member.id)
    }

    // Add or remove a member from the favorite list
    func toggleFavorite(for member: Member) {
        var currentFavorites = favoriteMemberIDs
        
        if isFavorite(member: member) {
            // Remove member from favorites
            currentFavorites.removeAll { $0 == member.id }
        } else {
            // Add member to favorites
            currentFavorites.append(member.id)
        }
        
        // Update the AppStorage value with the modified favorites list
        favoriteMemberIDs = currentFavorites
    }
}

// ObservableObject to manage members and favorite members
class MemberData: ObservableObject {
    @Published var members: [Member] = []
    @Published var showOnlyFavorites: Bool = false
    
    init() {
        loadMembers()
    }
    
    func loadMembers() {
        if let url = Bundle.main.url(forResource: "mps", withExtension: "json"),
           let data = try? Data(contentsOf: url) {
            let decoder = JSONDecoder()
            if let decodedMembers = try? decoder.decode([Member].self, from: data) {
                self.members = decodedMembers
            }
        }
    }
}

extension Color {
    static let partyColors: [String: Color] = [
        "ps": .blue,
        "kesk": .green,
        "kok": .orange,
        "sd": .red,
        "liik": .yellow,
        "r": .purple,
        "vas": .pink,
        "vihr": .mint,
        "kd": .gray
    ]

    static func color(for party: String) -> Color {
        return partyColors[party] ?? .gray
    }
}

struct ContentView: View {
    @StateObject private var memberData = MemberData()
    @StateObject private var favoriteManager = FavoriteManager()

    var filteredMembers: [Member] {
        if memberData.showOnlyFavorites {
            return memberData.members.filter { favoriteManager.isFavorite(member: $0) }
        } else {
            return memberData.members
        }
    }

    var body: some View {
        NavigationView {
            VStack {
                Toggle("Show Only Favorite Members", isOn: $memberData.showOnlyFavorites)
                    .padding()
                
                List(filteredMembers) { member in
                    NavigationLink(destination: MemberDetailView(member: member).environmentObject(favoriteManager)) {
                        MemberRowView(member: member)
                            .environmentObject(favoriteManager)
                    }
                }
                .navigationTitle("Parliament Members")
            }
        }
    }
}

struct MemberRowView: View {
    let member: Member
    @EnvironmentObject var favoriteManager: FavoriteManager

    var isFavorite: Bool {
        favoriteManager.isFavorite(member: member)
    }

    var body: some View {
        HStack {
            Image(member.partyImageName())
                .resizable()
                .scaledToFill()
                .frame(width: 50, height: 50)
                .clipShape(Circle())
            VStack(alignment: .leading) {
                Text("\(member.first) \(member.last)")
                    .font(.headline)
                Text("\(member.constituency) • \(member.party.uppercased())")
                    .font(.subheadline)
                    .foregroundColor(Color.color(for: member.party))
            }
            Spacer()
            Button(action: {
                favoriteManager.toggleFavorite(for: member)
            }) {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .foregroundColor(isFavorite ? .red : .gray)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding()
    }
}

extension Member {
    func partyImageName() -> String {
        switch party {
        case "ps": return "ps"
        case "kesk": return "kesk"
        case "kok": return "kok"
        case "sd": return "sd"
        case "vihr": return "vihr"
        case "vas": return "vas"
        case "rkp": return "rkp"
        case "kd": return "kd"
        case "liik": return "liik"
        case "lib": return "lib"
        case "feminist": return "feminist"
        default: return "defaultImage"
        }
    }
}

#Preview {
    ContentView()
}
